// const CTASection = () => {
//     return (
//       <section className="w-full bg-[#F7F8FC] py-20 flex justify-center">
//         <div className="text-center">
//           {/* Title */}
//           <h2 className="text-2xl md:text-3xl font-bold text-gray-900">
//             Let us solve your problems next
//           </h2>
  
//           {/* CTA Button */}
//           <div className="mt-6">
//             <button className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6 rounded-full shadow-lg transition-all duration-300">
//               Get in touch
//             </button>
//           </div>
//         </div>
//       </section>
//     );
//   };
  
//   export default CTASection;
  